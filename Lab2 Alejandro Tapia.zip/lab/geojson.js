// var puntosa = JSON.parse(fs.readFileSync('GeoJson.json').toString());
// var puntosa = require('GeoJson.json');


var puntos= {
    "type": "FeatureCollection",
    "features": [
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    -84.0342939,
                    9.9453690
                ]
            },
            "properties": {
                "name": "Sabanilla",
                "iconName":"bikeIcon.png"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    -83.9892534,
                    9.9089185
                ]
            },
            "properties": {
                "name": "Tres Rios",
                "iconName":"bikeIcon.png"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    -83.9204377,
                    9.8642435
                ]
            },
            "properties": {
                "name": "Cartago Centro",
                "iconName":"bikeIcon.png"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    -83.9350935,
                    9.8800717
                ]
            },
            "properties": {
                "name": "Taras",
                "iconName":"bikeIcon.png"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    -83.8450325,
                    9.9776575
                ]
            },
            "properties": {
                "name": "Volcan Irazu",
                "iconName":"volcan.png"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    -83.8020874,
                    9.8398709
                ]
            },
            "properties": {
                "name": "Cachi",
                "iconName":"bikeIcon.png"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    -83.8569893,
                    9.8174831
                ]
            },
            "properties": {
                "name": "Mirador Orosi",
                "iconName":"montana.png"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    -83.6849907,
                    9.9053141
                ]
            },
            "properties": {
                "name": "Turrialba",
                "iconName":"montana.png"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    -83.7492966,
                    9.8979604
                ]
            },
            "properties": {
                "name": "Juan Viñas",
                "iconName":"montana.png"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    -83.8018426,
                    9.9124905
                ]
            },
            "properties": {
                "name": "Pacayas",
                "iconName":"bikeIcon.png"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    -83.7453359,
                    9.9656748
                ]
            },
            "properties": {
                "name": "Santa Cruz",
                "iconName":"montana.png"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    -83.9424471,
                    9.8939840
                ]
            },
            "properties": {
                "name": "Ochomogo SJ-Cartago",
                "iconName":"bikeIcon.png"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    -83.9451868,
                    9.8987624
                ]
            },
            "properties": {
                "name": "Ochomogo Cartago-SJ",
                "iconName":"bikeIcon.png"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    -83.8828360,
                    9.8887071
                ]
            },
            "properties": {
                "name": "Cristo Pacayas",
                "iconName":"bikeIcon.png"
            }
        }
    ]
}





