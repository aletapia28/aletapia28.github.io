
        var map = L.map('map').setView([9.9453690, -84.0342939], 9);

        
        var bikeIcon = L.Icon.extend({
            options: {
                iconSize: [38, 38],
                iconAnchor: [25],
                shadowAnchor: [4, 62],
                popupAnchor: [-3, -76]
            }
        });
        

        L.tileLayer('https://stamen-tiles-{s}.a.ssl.fastly.net/toner-lite/{z}/{x}/{y}{r}.{ext}', {
            attribution: 'Map tiles by <a href="http://stamen.com">Stamen Design</a>, <a href="http://creativecommons.org/licenses/by/3.0">CC BY 3.0</a> &mdash; Map data &copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors',
            subdomains: 'abcd',
            minZoom: 0,
            maxZoom: 20,
            ext: 'png'
        }).addTo(map);

        


        // L.Control.geocoder({
        //     position: 'topright',
        //     collapsed: true,
        //     placeholder: 'Search...',
        //     defaultMarkGeocode: true,
        //     geocoder: L.Control.Geocoder.mapbox('your-public-mapbox-key', {
        
        //     })
        // });
 

        function onEachFeature(feature, layer) {
            var popupContent = '';
            if (feature.properties && feature.properties.name) {
                popupContent += feature.properties.name;
            }
            layer.bindPopup(popupContent);
        }
        
        // var geojsonLayer = new L.GeoJSON.AJAX("GeoJson.json");       
        

        
        var control= L.Routing.control({  lineOptions:{
            styles:[ {color: 'black', opacity: 0.8, weight: 6}, {color: 'red', opacity: 1, weight: 2}]
              }, 
            waypoints: [
                L.latLng(9.9453690, -84.0342939),
                L.latLng(9.9089185, -83.9892534),
                L.latLng(9.8642435, -83.9204377),
                L.latLng(9.8800717, -83.9350935),
                L.latLng(9.8887071, -83.8828360),
                L.latLng(9.9776575, -83.8450325),
                L.latLng(9.8398709, -83.8020874),
                L.latLng(9.8174831, -83.8569893),
                L.latLng(9.9053141, -83.6849907),
                L.latLng(9.8979604, -83.7492966),
                L.latLng(9.9124905, -83.8018426),
                L.latLng(9.9656748, -83.7453359),
                L.latLng(9.8939840, -83.9424471),
                L.latLng(9.8987624, -83.9451868),
                L.latLng(9.9656748, -83.7453359)
            ], routeWhileDragging: true,
            collapsible: true,
            
          //  geocoder: L.Control.Geocoder.nominatim()
        
        }).addTo(map);
        control.hide();
 
        L.geoJSON(puntos, {
            style: function (feature) {
                return feature.properties && feature.properties.style;
            },
            onEachFeature: onEachFeature,
            pointToLayer: function (feature, latlng) {
                var bike = new bikeIcon({ iconUrl: feature.properties.iconName });
                return L.marker(latlng, { icon: bike });
            }
        }).addTo(map);